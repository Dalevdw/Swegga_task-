function price(el) {
    var parent = $(el).closest("tr");
    var price =
      parent.find(".price").val() == "" ? 1 : parent.find(".price").val();
    var qty = parent.find(".qty").val() == "" ? 1 : parent.find(".qty").val();
    var total = price * qty;
    parent.find(".total_price").val(total.toFixed(2));
  }
function calcTotal(cost1, cost2){
    var grandTotal = parseFloat(cost1)+parseFloat(cost2);
    alert ("The Total price is R"+grandTotal.toFixed(2))
}
